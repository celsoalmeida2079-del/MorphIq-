import './globals.css';
import { Analytics } from '@vercel/analytics/react';
export const metadata={title:'MorphIQ — Experimental Computational Representation',description:'MorphIQ investigates a new representation layer between human geometric intent and computational execution.',metadataBase:new URL('https://morphiq.com.br')};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}<Analytics/></body></html>}
