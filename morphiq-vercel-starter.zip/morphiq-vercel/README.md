# MorphIQ — Vercel starter

## Deploy
1. Create/import a Git repository.
2. Upload this project.
3. Import the repository into Vercel.
4. Framework: Next.js. Build command: `next build`.
5. Add your real domain `morphiq.com.br` after DNS is configured.

## Before publishing
- Replace `contact@morphiq.com.br` with the real mailbox.
- Review every public technical statement against the patent strategy.
- Do not claim NVIDIA partnership, endorsement, use of NVIDIA technology, validation, benchmark results or commercial readiness unless those facts are true and documented.
- Add the final pitch deck PDF when ready.
- Add Privacy Policy / Terms if analytics, forms or other data collection are enabled.

## Current demo
The Interactive Lab is intentionally a visualization. It records drawn points in the browser and displays an experimental pipeline; it does not execute arbitrary code or claim scientific validation.
