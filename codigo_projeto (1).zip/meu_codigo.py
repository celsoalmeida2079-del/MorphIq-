{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 1,
   "id": "7e19c143",
   "metadata": {},
   "outputs": [],
   "source": [
    "import numpy as np\n",
    "import matplotlib.pyplot as plt\n",
    "\n",
    "# 1. Recuperando a linha do tempo e a onda JMP pura da Fase 1\n",
    "tempo = np.linspace(0, 1.0, 500, endpoint=False)\n",
    "freq_jmp = 15\n",
    "amplitude_padrao = 10\n",
    "onda_pura_jmp = amplitude_padrao * np.sin(2 * np.pi * freq_jmp * tempo)\n",
    "\n",
    "# 2. Gerando o Escudo Polimórfico (Ruído Gaussiano Caótico Tridimensional)\n",
    "# Mude o valor de 'intensidade_ruido' se quiser ver o sinal mais trêmulo ou mais limpo\n",
    "intensidade_ruido = 3.5\n",
    "ruido_caotico = np.random.normal(0, intensidade_ruido, onda_pura_jmp.shape)\n",
    "\n",
    "# 3. Mistura Criptográfica: Onda Camuflada que trafega no sistema\n",
    "onda_criptografada = onda_pura_jmp + ruido_caotico\n",
    "\n",
    "# 4. Renderização Gráfica do Experimento 2\n",
    "fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 6))\n",
    "\n",
    "# Gráfico Superior: O sinal que o invasor intercepta\n",
    "ax1.plot(tempo, onda_criptografada, color='crimson', linewidth=1.5, label='Onda Camuflada (Ruído Ativo)')\n",
    "ax1.set_title(\"Sinal Interceptado em Trânsito (Nuvem/RAM): CÓDIGO INUTILIZÁVEL\")\n",
    "ax1.grid(True)\n",
    "ax1.legend()\n",
    "\n",
    "# Gráfico Inferior: A comparação estrutural que o Dr. Wesley e a NVIDIA querem avaliar\n",
    "ax2.plot(tempo, onda_criptografada, color='crimson', alpha=0.4, label='Sinal Camuflado')\n",
    "ax2.plot(tempo, onda_pura_jmp, color='purple', linestyle='--', linewidth=2, label='Espinha Dorsal Lógica (JMP)')\n",
    "ax2.set_title(\"Análise de Espectro: Estrutura Lógica Oculta sob o Polimorfismo\")\n",
    "ax2.grid(True)\n",
    "ax2.legend()\n",
    "\n",
    "plt.tight_layout()\n",
    "plt.show()\n",
    "\n",
    "print(\"✅ [EXPERIMENTO FASE 2]: Escudo polimórfico ativado. Onda original camuflada em ruído estocástico.\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "id": "e2218a8b",
   "metadata": {},
   "outputs": [],
   "source": [
    "import numpy as np\n",
    "import matplotlib.pyplot as plt\n",
    "\n",
    "# 1. Recuperando a linha do tempo e a onda JMP pura da Fase 1\n",
    "tempo = np.linspace(0, 1.0, 500, endpoint=False)\n",
    "freq_jmp = 15\n",
    "amplitude_padrao = 10\n",
    "onda_pura_jmp = amplitude_padrao * np.sin(2 * np.pi * freq_jmp * tempo)\n",
    "\n",
    "# 2. Gerando o Escudo Polimórfico (Ruído Gaussiano Caótico Tridimensional)\n",
    "# Mude o valor de 'intensidade_ruido' se quiser ver o sinal mais trêmulo ou mais limpo\n",
    "intensidade_ruido = 3.5\n",
    "ruido_caotico = np.random.normal(0, intensidade_ruido, onda_pura_jmp.shape)\n",
    "\n",
    "# 3. Mistura Criptográfica: Onda Camuflada que trafega no sistema\n",
    "onda_criptografada = onda_pura_jmp + ruido_caotico\n",
    "\n",
    "# 4. Renderização Gráfica do Experimento 2\n",
    "fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 6))\n",
    "\n",
    "# Gráfico Superior: O sinal que o invasor intercepta\n",
    "ax1.plot(tempo, onda_criptografada, color='crimson', linewidth=1.5, label='Onda Camuflada (Ruído Ativo)')\n",
    "ax1.set_title(\"Sinal Interceptado em Trânsito (Nuvem/RAM): CÓDIGO INUTILIZÁVEL\")\n",
    "ax1.grid(True)\n",
    "ax1.legend()\n",
    "\n",
    "# Gráfico Inferior: A comparação estrutural que o Dr. Wesley e a NVIDIA querem avaliar\n",
    "ax2.plot(tempo, onda_criptografada, color='crimson', alpha=0.4, label='Sinal Camuflado')\n",
    "ax2.plot(tempo, onda_pura_jmp, color='purple', linestyle='--', linewidth=2, label='Espinha Dorsal Lógica (JMP)')\n",
    "ax2.set_title(\"Análise de Espectro: Estrutura Lógica Oculta sob o Polimorfismo\")\n",
    "ax2.grid(True)\n",
    "ax2.legend()\n",
    "\n",
    "plt.tight_layout()\n",
    "plt.show()\n",
    "\n",
    "print(\"✅ [EXPERIMENTO FASE 2]: Escudo polimórfico ativado. Onda original camuflada em ruído estocástico.\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "id": "65c35d42",
   "metadata": {},
   "outputs": [],
   "source": [
    "from google.colab import files\n",
    "files.download('nome_do_seu_arquivo.csv')"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "id": "61988026",
   "metadata": {},
   "outputs": [],
   "source": [
    "from google.colab import files\n",
    "files.download(experimentos)"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "id": "5327a85f",
   "metadata": {},
   "outputs": [],
   "source": [
    "from google.colab import files\n",
    "files.download('nome_do_seu_arquivo.csv')\n",
    "Experimento"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "id": "9423bc0c",
   "metadata": {},
   "outputs": [],
   "source": [
    "from google.colab import files\n",
    "files.download.zip"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "id": "72ec8eb6",
   "metadata": {},
   "outputs": [],
   "source": [
    "import shutil\n",
    "\n",
    "# Substitua 'nome_do_arquivo_zip' pelo nome que você deseja dar ao seu ZIP\n",
    "# Substitua 'caminho_da_pasta_ou_arquivo' pelo que você quer compactar\n",
    "shutil.make_archive('nome_do_arquivo_zip', 'zip', './') \n",
    "\n",
    "print(\"Arquivo ZIP criado com sucesso!\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "id": "e51335cb",
   "metadata": {},
   "outputs": [],
   "source": [
    "import os\n",
    "import shutil\n",
    "\n",
    "# 1. Cria uma pasta temporária para colocar o que você quer salvar\n",
    "os.makedirs('para_salvar', exist_ok=True)\n",
    "\n",
    "# 2. Salva o histórico do seu notebook atual como um arquivo .py dentro da pasta\n",
    "# (Isso vai extrair o código que você escreveu nas células)\n",
    "%notebook -e para_salvar/meu_codigo.py\n",
    "\n",
    "# 3. Compacta apenas essa pasta nova, evitando os arquivos do Drive\n",
    "shutil.make_archive('codigo_projeto', 'zip', 'para_salvar')\n",
    "\n",
    "print(\"Arquivo 'codigo_projeto.zip' criado com sucesso!\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 9,
   "id": "c90d302e",
   "metadata": {},
   "outputs": [],
   "source": [
    "import os\n",
    "import shutil\n",
    "\n",
    "# 1. Cria uma pasta temporária para colocar o que você quer salvar\n",
    "os.makedirs('para_salvar', exist_ok=True)\n",
    "\n",
    "# 2. Salva o histórico do seu notebook atual como um arquivo .py dentro da pasta\n",
    "# (Isso vai extrair o código que você escreveu nas células)\n",
    "%notebook -e para_salvar/meu_codigo.py\n",
    "\n",
    "# 3. Compacta apenas essa pasta nova, evitando os arquivos do Drive\n",
    "shutil.make_archive('codigo_projeto', 'zip', 'para_salvar')\n",
    "\n",
    "print(\"Arquivo 'codigo_projeto.zip' criado com sucesso!\")"
   ]
  }
 ],
 "metadata": {},
 "nbformat": 4,
 "nbformat_minor": 5
}
